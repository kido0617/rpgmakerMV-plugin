/*---------------------------------------------------------------------------*
 * 2019/10/11 @kido0617
 * https://kido0617.github.io/
 * TestReport.jsについては完全に自由にどうぞ。クレジットの表記もいりません。
 * フォルダ内のbootstrap.min.cssはMITライセンスによりTwitter社が配布しています。https://github.com/twbs/bootstrap/blob/v4.1.3/LICENSE
 * Ver.1.0
 *---------------------------------------------------------------------------*/

/*:
 * @plugindesc テストするときのレポートを書きやすくするプラグイン
 * @author @kido0617
 * @help
 * 詳細
 * https://kido0617.github.io/rpgmaker/2019-10-11-test-report
 * 
*/


(function(){

  var initNwjs = SceneManager.initNwjs;
  SceneManager.initNwjs = function() {
    initNwjs.call(this);

    if (Utils.isNwjs()){
      var gui = window.require('nw.gui');
      var win = gui.Window.get();

      if(win.subWindowInited)return;

      win.subWindowInited = true;
      var dir = Utils.isOptionValid('test') ? './' : './www/';
      
      gui.Window.open(dir + 'js/plugins/TestReport/SubWindow.html', {
        resizable: false
      }, (w) => {
        w.on('loaded', () => {
          w.window.initNw(win, Graphics.width, 0);
          win.focus();
        });
      });
    }
  };
})();